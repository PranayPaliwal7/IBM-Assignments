package com.ibm.bank.dao;
import com.ibm.bank.bean.*;
import com.ibm.bank.dao.XYZBankDaoInterface;
import java.util.*;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
public class XYZBankDaoClass implements XYZBankDaoInterface{
	Connection dbCon;
	PreparedStatement pstmt;
	PreparedStatement pstmt2;
	PreparedStatement pstmt3;
	ArrayList<String> list = new ArrayList<String>();
	public XYZBankDaoClass() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			dbCon = DriverManager.getConnection("jdbc:mysql://localhost:3307/ibmtraining?serverTimezone=IST", "root", "");
		}catch(Exception e) {
			System.out.println(e);
		}
	}
	

		public boolean InsertData(String Name, String UserName, String userPassword, int amount) {
			String insertQry = "INSERT INTO customerdetails (NAME, USERNAME, PASSWORD, AMOUNT) VALUES (?,?,?,?)";
			try {

				pstmt = dbCon.prepareStatement(insertQry);
				pstmt.setString(1, Name);
				pstmt.setString(2, UserName);
				pstmt.setString(3, userPassword);
				pstmt.setInt(4, amount);

				if(pstmt.executeUpdate()>0) {
					return true;
				}
				else {
					return false;
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			return false;
		}

		public void login(String UserName, String userPassword) {
			String loginQry = "SELECT * FROM customerdetails where USERNAME=? and PASSWORD=?";
			try {
				pstmt = dbCon.prepareStatement(loginQry);
				pstmt.setString(1,UserName);
				pstmt.setString(2,userPassword);

				if(pstmt.execute()) {
					System.out.println("Successfully Logged In. ");
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		public boolean validateLogin(String UserName, String userPassword) {
			String ValidateQry = "SELECT * FROM customerdetails where USERNAME=?";
			try {
				pstmt = dbCon.prepareStatement(ValidateQry);
				pstmt.setString(1,UserName);
				
				ResultSet rs = pstmt.executeQuery();

				if(rs.next()) {
					if(rs.getString("PASSWORD").equals(userPassword)) {
						return true;
					}
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			return false;
		}

	
		public int ShowBalance(String UserName) {
			String ShowBalanceQry = "SELECT amount FROM customerdetails where (USERNAME=?)";
			try {
				pstmt = dbCon.prepareStatement(ShowBalanceQry);
				pstmt.setString(1,UserName);
				ResultSet rs = pstmt.executeQuery();   
				int balance = 0;
				
				while (rs.next()) {         
					balance = rs.getInt("AMOUNT");   
					

				}
				if(pstmt.execute()) {
					return balance;
				}
				else {
					return -100;
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			return 0;
		}
         
//		public boolean PrintTransactions(String UserName) {
//			String PrintTransactionsQry = "SELECT * FROM customerdetails where (USERNAME=?)";
//			try {
//				pstmt = dbCon.prepareStatement(PrintTransactionsQry);
//				pstmt.setString(1,UserName);
//				
//				
//				if(pstmt.execute()) {
//					return true;
//				}
//				else {
//					return false;
//				}
//			} catch (SQLException e) {
//				e.printStackTrace();
//			}
//			return false;
//		}

		public boolean FundTransfer(String UserNameSender, String UserNameReciever, int amount) {
			String FundTransferQry = "UPDATE customerdetails SET AMOUNT=AMOUNT + ?  WHERE USERNAME=?";
			String FundTransferQry2 = "UPDATE customerdetails SET AMOUNT=AMOUNT - ?  WHERE USERNAME=?";
			String FundTransferQry3 = "SELECT amount FROM customerdetails WHERE USERNAME=?";

			try {


				pstmt3 = dbCon.prepareStatement(FundTransferQry3);

				pstmt3.setString(1, UserNameSender);


				ResultSet rs = pstmt3.executeQuery();
				int amount1=0;

				while (rs.next()) {         
					amount1= rs.getInt("AMOUNT");
				}

				if(pstmt3.execute()) {

					if(amount1<amount)
						System.out.println("Insufficient balance");
					else {

						pstmt = dbCon.prepareStatement(FundTransferQry);
						pstmt2 = dbCon.prepareStatement(FundTransferQry2);

						pstmt.setInt(1, amount);
						pstmt.setString(2, UserNameReciever);
						pstmt2.setInt(1, amount);
						pstmt2.setString(2, UserNameSender);

						if (pstmt.executeUpdate()>0 && pstmt2.executeUpdate()>0)
							return true;



						else {
							return false;
						}
					} }}catch (SQLException e) {
						e.printStackTrace();
					}
			return false;
		}

		public boolean WithdrawMoney(String UserName, int amount) {
			String WithdrawMoneyQry = "UPDATE customerdetails SET AMOUNT=AMOUNT - ?  WHERE USERNAME=?";
				try {

					pstmt = dbCon.prepareStatement(WithdrawMoneyQry);
					pstmt.setInt(1, amount);
					pstmt.setString(2, UserName);
					if(pstmt.executeUpdate()>0) {
						return true;
					}
					else {
						return false;
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
				return false;
			}


			public boolean DepositMoney(String UserName, int amount) {
				String DepositQry = "UPDATE customerdetails SET AMOUNT=AMOUNT + ?  WHERE USERNAME=?";
				try {

					pstmt = dbCon.prepareStatement(DepositQry);

					pstmt.setInt(1, amount);
					pstmt.setString(2, UserName);

					if(pstmt.executeUpdate()>0) {

						return true;

					}
					else {
						return false;
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
				return false;
			}


			@Override
			public void insertData(String Name, String Email, int Pin) {
				// TODO Auto-generated method stub
				
			}
			
			public ArrayList<String> viewTransactions(String UserName) {
				
				String fetchQry = "select * from customerdetails where USERNAME = ?";
				
				try {
					
					pstmt = dbCon.prepareStatement(fetchQry);
					pstmt.setString(1, UserName);
					
					ResultSet rs = pstmt.executeQuery();
				
					while(rs.next()) {
						list.add(rs.getString("UserName"));
						list.add(rs.getString("transferType"));
						list.add((Integer.toString(rs.getInt("transactionAmount"))));
						list.add((Integer.toString(rs.getInt("userBalance"))));
					}
				}catch(Exception e){
					System.out.println(e);
				}
				return list;
			}


			




		}

