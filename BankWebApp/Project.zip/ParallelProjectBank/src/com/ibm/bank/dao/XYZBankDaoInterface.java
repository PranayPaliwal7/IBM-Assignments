package com.ibm.bank.dao;

import java.sql.*;
import java.util.*;
import com.ibm.bank.bean.*;

public interface XYZBankDaoInterface {


	public void insertData(String Name, String Email, int Pin);
	
}
