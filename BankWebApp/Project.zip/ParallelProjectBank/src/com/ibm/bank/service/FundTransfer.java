package com.ibm.bank.service;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ibm.bank.XYZBank;
import com.ibm.bank.dao.XYZBankDaoClass;

/**
 * Servlet implementation class FundTransfer
 */
@WebServlet("/FundTransfer")
public class FundTransfer extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		XYZBankDaoClass dao=new XYZBankDaoClass();
        HttpSession session = request.getSession();
		
		String UserName = (String) session.getAttribute("currentUser");
		String UserNameReciever = request.getParameter("usernamereciever");
		int amount = Integer.parseInt(request.getParameter("amount"));
		
		if(dao.FundTransfer(UserName,UserNameReciever, amount)) {
			String message = "Transferred Successfully.";
			request.setAttribute("message", message);
			request.getRequestDispatcher("afterlogin.jsp").forward(request, response);
			
		} else { 
			String message = "Failed.Try Again.";
			request.setAttribute("message", message);
			request.getRequestDispatcher("afterlogin.jsp").forward(request, response);
	}	
	}

	

}
