package com.ibm.bank.service;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ibm.bank.XYZBank;
import com.ibm.bank.dao.XYZBankDaoClass;

@WebServlet("/ShowBalance")
public class ShowBalance extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		XYZBankDaoClass	dao = new XYZBankDaoClass();
		HttpSession session = request.getSession();
		String userName = (String) session.getAttribute("currentUser");
		int balance = dao.ShowBalance(userName);
		if(balance>=0) {
			String message = Integer.toString(balance);
			request.setAttribute("message", message);
			request.getRequestDispatcher("sb.jsp").forward(request, response);
			
		} else { 
			String message = "Please try again later...";
			request.setAttribute("message", message);
			request.getRequestDispatcher("afterlogin.jsp").forward(request, response);
	}		
	
	}


}
