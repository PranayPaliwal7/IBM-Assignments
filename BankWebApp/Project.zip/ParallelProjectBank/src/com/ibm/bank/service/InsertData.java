package com.ibm.bank.service;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ibm.bank.XYZBank;
import com.ibm.bank.dao.XYZBankDaoClass;

/**
 * Servlet implementation class InsertData
 */
@WebServlet("/InsertData")
public class InsertData extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		XYZBankDaoClass dao=new XYZBankDaoClass();
		String UserName = request.getParameter("username");
		String userPassword = request.getParameter("password");
		int amount = Integer.parseInt(request.getParameter("amount"));
		String Name = request.getParameter("name");
		
		if(dao.InsertData(Name, UserName, userPassword, amount)) {
			HttpSession session = request.getSession();
			session.setAttribute("currentUser", UserName);
			response.sendRedirect("login.jsp");
			
		} else { 
			String message = "Could Not Create. Try Again";
			request.setAttribute("message", message);
			request.getRequestDispatcher("register.jsp").forward(request, response);
	}	
	}

	
}
