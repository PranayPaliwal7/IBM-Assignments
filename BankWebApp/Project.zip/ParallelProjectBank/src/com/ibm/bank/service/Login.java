package com.ibm.bank.service;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ibm.bank.XYZBank;
import com.ibm.bank.dao.XYZBankDaoClass;

@WebServlet("/Login")
public class Login extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		XYZBankDaoClass dao=new XYZBankDaoClass();
		
		String UserName = request.getParameter("username");
		String userPassword = request.getParameter("password");
		
		if(dao.validateLogin(UserName, userPassword)) {
			HttpSession session = request.getSession();
			session.setAttribute("currentUser", UserName);
			response.sendRedirect("afterlogin.jsp");
			
		} else { 
			String message = "Wrong username/password.";
			request.setAttribute("message", message);
			request.getRequestDispatcher("login.jsp").forward(request, response);
	}	
	}
}
