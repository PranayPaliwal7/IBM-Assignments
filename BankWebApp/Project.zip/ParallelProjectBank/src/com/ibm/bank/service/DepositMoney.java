package com.ibm.bank.service;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ibm.bank.XYZBank;
import com.ibm.bank.dao.XYZBankDaoClass;

@WebServlet("/DepositMoney")
public class DepositMoney extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		XYZBankDaoClass dao=new XYZBankDaoClass();
		XYZBank bean=new XYZBank();
		HttpSession session = request.getSession();
		
		String UserName = (String) session.getAttribute("currentUser");
		int amount = Integer.parseInt(request.getParameter("amount"));
		
		if(dao.DepositMoney(UserName, amount)) { 
			String message = "Successfully deposited.";
			request.setAttribute("message", message);
			request.getRequestDispatcher("afterlogin.jsp").forward(request, response);
			
		} else { 
			String message = "Failed.Try Again.";
			request.setAttribute("message", message);
			request.getRequestDispatcher("afterlogin.jsp").forward(request, response);
	}	
	}

}
