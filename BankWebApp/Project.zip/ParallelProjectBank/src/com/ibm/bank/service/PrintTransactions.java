package com.ibm.bank.service;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ibm.bank.dao.XYZBankDaoClass;

@WebServlet("/PrintTransactions")
public class PrintTransactions extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		XYZBankDaoClass	dao = new XYZBankDaoClass();
		ArrayList<String> list = new ArrayList<String>();
		HttpSession session = request.getSession();

		if(session!=null && session.getAttribute("currentUser")!=null) {
			
		
			
			
			String UserName = (String)session.getAttribute("currentUser");
			
			list=dao.viewTransactions(UserName);
			
			StringBuilder sb = new StringBuilder("");
			
			int len = list.size();
			int count = 0;
			System.out.println(len);
			while(count<len) {
				
				sb.append("<br>");
				sb.append("[User Name: " + list.get(count));
				sb.append("  ||  User Phone Number: "+ list.get(++count));
				sb.append("  ||  Transaction Type: "+ list.get(++count));
				sb.append("  ||  Transaction Amount: "+ list.get(++count));
				sb.append("  ||  Balance: "+ list.get(++count)+" ]<br>");
				sb.append("------------------------------------------------------------------"
						+ "---------------------------------------------------------------------------<br>");
	
				count++;
			}
			
			String message2 = sb.toString();
			request.setAttribute("message2", message2);
			request.getRequestDispatcher("afterlogin.jsp").forward(request, response);	
		} else {
			
			String message = "Please login first.";
			request.setAttribute("message", message);
			request.getRequestDispatcher("login.jsp").forward(request, response);
			
		}
	}
			
			
	}


