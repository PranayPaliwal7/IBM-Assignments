package com.ibm.bank;

public class XYZBank {

}
