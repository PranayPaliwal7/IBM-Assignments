package com.ibm.training;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Service {

	@Autowired
	NamedParamDemo dao;

	public void InsertData(String Name, String UserName2, String Password1, int amount1) {
		System.out.println("NAME: " + Name + ", dao: " + dao);
		dao.InsertData(Name, UserName2, Password1, amount1);
		System.out.println("second");
	}

	public void WithdrawMoney(String UserName, int amount) {
		dao.WithdrawMoney(UserName, amount);
	}

	public void DepositMoney(String UserName, int amount) {
		dao.DepositMoney(UserName, amount);
	}

	public void ShowBalance(String UserName) {
		dao.ShowBalance(UserName);
	}

	public boolean login(String UserName, String userPassword) {
		return dao.login(UserName, userPassword);
	}

	public void FundTransfer(String UserNameSender, String UserNameReciever, int amount) {
		dao.FundTransfer(UserNameSender, UserNameReciever, amount);
	}

}
