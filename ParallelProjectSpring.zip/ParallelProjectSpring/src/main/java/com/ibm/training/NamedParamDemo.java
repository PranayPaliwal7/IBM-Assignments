package com.ibm.training;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository("dao")
public class NamedParamDemo {

	DataSource dataSource;
	NamedParameterJdbcTemplate namedParam;

	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
		namedParam = new NamedParameterJdbcTemplate(dataSource);
	}

	public void InsertData(String Name, String UserName, String userPassword, int amount) {
		String qry = "INSERT INTO customerdetails (NAME, USERNAME, PASSWORD, AMOUNT) VALUES (:nm, :un, :pw, :am)";
		namedParam.update(qry, new MapSqlParameterSource("nm", Name).addValue("un", UserName)
				.addValue("pw", userPassword).addValue("am", amount));
		System.out.println("Account Created Successfully. Login Now");

	}

	public void WithdrawMoney(String UserName, int amount) {
		String qry = "UPDATE customerdetails SET AMOUNT=AMOUNT - :am  WHERE USERNAME=:un";
		namedParam.update(qry, new MapSqlParameterSource("am", amount).addValue("un", UserName));
		System.out.println("Withdrawn succesfully.");
	}

	public void DepositMoney(String UserName, int amount) {
		String qry = "UPDATE customerdetails SET AMOUNT=AMOUNT + :am  WHERE USERNAME=:un";
		namedParam.update(qry, new MapSqlParameterSource("am", amount).addValue("un", UserName));
		System.out.println("Deposited Successfully.");
	}

	public void FundTransfer(String UserNameSender, String UserNameReciever, int amount) {
		String qry1 = "UPDATE customerdetails SET AMOUNT=AMOUNT + :am1  WHERE USERNAME=:un1";
		String qry2 = "UPDATE customerdetails SET AMOUNT=AMOUNT - :am2  WHERE USERNAME=:un2";
		String qry3 = "SELECT amount FROM customerdetails WHERE USERNAME=:un3";
		namedParam.update(qry1, new MapSqlParameterSource("am1", amount).addValue("un1", UserNameReciever));
		namedParam.update(qry2, new MapSqlParameterSource("am2", amount).addValue("un2", UserNameSender));
		namedParam.queryForObject(qry3, new MapSqlParameterSource("un3", UserNameSender), Integer.class);
		System.out.println("Transferred Successfully");
	}

	public void ShowBalance(String UserName) {
		String qry = "SELECT amount FROM customerdetails where (USERNAME=:un)";
		System.out.println("Available Balance is: "
				+ namedParam.queryForObject(qry, new MapSqlParameterSource("un", UserName), Integer.class));
	}

	public boolean login(String UserName, String userPassword) {
		String qry = "SELECT PASSWORD FROM customerdetails WHERE USERNAME=:un";
		String x = namedParam.queryForObject(qry, new MapSqlParameterSource("un", UserName), String.class);
		if (userPassword.equals(x)) {
			return true;
		} else {
			return false;
		}

	}
}