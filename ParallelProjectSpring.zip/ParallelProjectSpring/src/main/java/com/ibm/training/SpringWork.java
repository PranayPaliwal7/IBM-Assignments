package com.ibm.training;

import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("spring")
public class SpringWork {

	@Autowired
	Service service;

	public void XYZBank() {
		Scanner sc = new Scanner(System.in);

		String Name;
		try {
			while (true) {

				System.out.println("                                            Welcome to XYZ Bank Wallet");
				System.out.println("Press 1. Create Account");
				System.out.println("Press 2. Already have an account ?");
				int choice = sc.nextInt();
				switch (choice) {
				case (1):

					System.out.println("Enter your Name");
					Name = sc.next();
					System.out.println("Enter your UserName ");
					String UserName2 = sc.next();
					System.out.println("Enter Password ");
					String Password1 = sc.next();
					System.out.println("Enter the amount you want to add to the account");
					int amount1 = sc.nextInt();
					service.InsertData(Name, UserName2, Password1, amount1);
					break;
				case (2):

					System.out.println("Enter the Login Details");
					System.out.println("Enter the UserName");
					String Username1 = sc.next();
					System.out.println("Enter the Password");
					String pass = sc.next();
					if (service.login(Username1, pass)) {
						while (true) {
							System.out.println("Press 1. Show Balance");
							System.out.println("Press 2. Fund Transfer");
							System.out.println("Press 3. Withdraw Money");
							System.out.println("Press 4. Deposit Money");
							int ch = sc.nextInt();
							switch (ch) {
							case (1):
								service.ShowBalance(Username1);
								break;
							case (2):
								System.out.println(
										"Enter the Email ID of the user into which you want to transfer money");
								String UserNameReciever = sc.next();
								System.out.println("Enter the amount");
								int amount2 = sc.nextInt();
								service.FundTransfer(Username1, UserNameReciever, amount2);
								break;
							case (3):
								System.out.println("Enter the amount you want to withdraw");
								int amount3 = sc.nextInt();
								service.WithdrawMoney(Username1, amount3);
								break;
							case (4):
								System.out.println("Enter the amount you want to deposit");
								int amount4 = sc.nextInt();
								service.DepositMoney(Username1, amount4);
								break;
							}
						}
					} else {
						System.out.println("Incorrect details. Try login again");
					}
				}
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

}
