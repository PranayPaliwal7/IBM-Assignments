package com.ibm.training;

import java.util.Scanner;
import com.ibm.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {

	public static void main(String[] args) {

		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("appContextBank.xml");
		SpringWork dao = context.getBean("spring", SpringWork.class);

		dao.XYZBank();
	}
}
